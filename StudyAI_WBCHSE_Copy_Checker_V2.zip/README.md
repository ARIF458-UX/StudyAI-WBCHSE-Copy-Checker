# StudyAI WBCHSE Copy Checker V2

A free-to-deploy Streamlit web app for AI-assisted evaluation of WBCHSE Class 11–12 question papers and handwritten answer-sheet PDFs.

## Important
- This is an AI-assisted draft evaluator. A teacher/student must verify the marks.
- Handwriting recognition can be imperfect, especially with faint, tilted, or unclear writing.
- The app sends selected PDF page images to the Gemini API. Check the provider's current privacy and free-tier terms before uploading personal documents.
- Never commit your API key to GitHub.

## Deploy online (Chrome)
1. Create a GitHub account (if you do not already have one).
2. Create a **public** repository named `studyai-wbchse-copy-checker`.
3. Upload `app.py` and `requirements.txt` from this folder. You may also upload this README.
4. Open Streamlit Community Cloud and sign in with GitHub.
5. Choose **Create app**, select your repository, branch `main`, and file `app.py`.
6. In the app's settings, open **Secrets** and add:
   `GEMINI_API_KEY = "YOUR_GEMINI_API_KEY"`
7. Deploy. Open the generated Streamlit URL in Chrome.

## Get an API key
Create a Gemini API key through Google AI Studio. Check the current availability, quotas, age/account requirements, and pricing for your account/region. The app itself is free, but AI usage may have free-tier limits or paid usage depending on current terms.

## Local test (optional)
Python 3.11+ recommended:
```bash
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```
Create `.streamlit/secrets.toml`:
```toml
GEMINI_API_KEY = "YOUR_GEMINI_API_KEY"
```
Run:
```bash
streamlit run app.py
```

## Current limits
- Sends up to the selected number of pages from each PDF (1–20).
- For large papers, process in smaller page batches.
- The report may need manual correction; this is not an official WBCHSE marking scheme.
