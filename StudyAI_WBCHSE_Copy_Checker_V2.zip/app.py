import os
import json
import streamlit as st
import fitz
from PIL import Image
from io import BytesIO
from google import genai
from google.genai import types

st.set_page_config(page_title="StudyAI | WBCHSE Copy Checker", page_icon="📘", layout="wide")

st.markdown("""
<style>
:root { color-scheme: light; }
.block-container {max-width: 1120px; padding-top: 2rem; padding-bottom: 3rem;}
.hero {padding: 1.5rem 1.7rem; border-radius: 18px; background: linear-gradient(120deg,#101a35,#243d68); color:white; margin-bottom:1.2rem;}
.hero h1 {font-size:2.15rem; margin:0 0 .35rem 0;}
.hero p {color:#dce7ff; margin:0;}
.small-note {color:#667085; font-size:.88rem;}
div[data-testid="stMetric"] {background:#f6f8fc; padding:14px; border-radius:12px;}
</style>
<div class="hero">
<h1>📘 StudyAI</h1>
<p>WBCHSE Class 11–12 · AI-powered PDF answer-sheet evaluation</p>
</div>
""", unsafe_allow_html=True)

st.write("Upload the question paper and a student's answer-sheet PDF. StudyAI will prepare a question-wise draft evaluation.")
st.info("This is an AI-assisted draft checker, not an official examiner. Please review marks before using them.")

def pdf_to_parts(uploaded, max_pages, dpi=125):
    doc = fitz.open(stream=uploaded.getvalue(), filetype="pdf")
    parts = []
    total = min(len(doc), max_pages)
    for i in range(total):
        page = doc.load_page(i)
        pix = page.get_pixmap(matrix=fitz.Matrix(dpi/72, dpi/72), alpha=False)
        img = Image.open(BytesIO(pix.tobytes("png"))).convert("RGB")
        parts.append((i+1, img))
    return len(doc), parts

def build_prompt(subject, class_name, total_marks, instructions, q_count):
    return f"""
You are a careful West Bengal Council of Higher Secondary Education (WBCHSE) answer-script evaluator.
Evaluate the student's uploaded answer sheet against the uploaded question paper.
Class: {class_name}
Subject: {subject}
Maximum marks (if supplied): {total_marks or 'Not specified'}
Teacher instructions: {instructions or 'None'}

The question paper pages are provided first, followed by answer-sheet pages.
Read printed text and handwriting from the page images. If handwriting is unclear, say so instead of guessing.
Match answers to question numbers. Do not invent questions, answers, or marking-scheme details.
Award fair partial credit for correct steps and relevant points. Be cautious with handwriting/OCR uncertainty.
If a question's printed marks are visible, use them. Otherwise state that the mark allocation is unclear.
Return:
1. A short overall summary.
2. A Markdown table with columns: Question, Expected answer/key points, Student's answer assessment, Marks awarded, Max marks, Feedback.
3. Total marks awarded and total maximum marks only where they can be reliably determined.
4. Important corrections and topics to revise.
5. A list of any pages/answers that need human rechecking.
If the full paper exceeds the provided pages, clearly disclose this.
Do not claim certainty where the image is unclear.
"""

st.subheader("1. Upload PDFs")
c1, c2 = st.columns(2)
with c1:
    question_pdf = st.file_uploader("Question Paper PDF", type=["pdf"], key="qp")
with c2:
    answer_pdf = st.file_uploader("Student Answer Sheet PDF", type=["pdf"], key="ans")

c3, c4, c5 = st.columns([1,1,1])
with c3:
    class_name = st.selectbox("Class", ["Class 11", "Class 12"])
with c4:
    subject = st.text_input("Subject", placeholder="e.g. Mathematics")
with c5:
    total_marks = st.number_input("Paper total marks (optional)", min_value=0, max_value=1000, value=0, step=1)

instructions = st.text_area("Additional checking instructions (optional)", placeholder="e.g. Give step marks; accept equivalent methods.")
max_pages = st.slider("Maximum pages to send from each PDF", min_value=1, max_value=20, value=8)
st.caption("For a free-tier AI account, start with 3–5 pages per PDF. Larger PDFs may hit model limits or take longer.")

api_key = None
try:
    api_key = st.secrets.get("GEMINI_API_KEY", None)
except Exception:
    api_key = None
api_key = api_key or os.environ.get("GEMINI_API_KEY")

with st.expander("API key setup"):
    st.write("For private/local testing, add your Gemini API key to `.streamlit/secrets.toml` as `GEMINI_API_KEY = \"your-key\"`. For Streamlit Community Cloud, add it under App → Settings → Secrets. Never paste your key into public code or share it.")

if st.button("🚀 Evaluate Answer Sheet", type="primary", use_container_width=True):
    if not question_pdf or not answer_pdf:
        st.error("Please upload both PDF files.")
    elif not subject.strip():
        st.error("Please enter the subject.")
    elif not api_key:
        st.error("Gemini API key not found. See API key setup above.")
    else:
        try:
            with st.spinner("Reading PDF pages and evaluating answers…"):
                q_total, q_pages = pdf_to_parts(question_pdf, max_pages)
                a_total, a_pages = pdf_to_parts(answer_pdf, max_pages)
                client = genai.Client(api_key=api_key)
                contents = [build_prompt(subject, class_name, total_marks, instructions, None)]
                contents.append("QUESTION PAPER PAGES:")
                for page_no, img in q_pages:
                    contents.extend([f"Question paper page {page_no}", img])
                contents.append("STUDENT ANSWER-SHEET PAGES:")
                for page_no, img in a_pages:
                    contents.extend([f"Answer sheet page {page_no}", img])

                response = client.models.generate_content(
                    model="gemini-2.5-flash",
                    contents=contents,
                    config=types.GenerateContentConfig(temperature=0.2)
                )
                st.session_state["evaluation"] = response.text or "The model returned an empty response."
                st.session_state["page_info"] = (q_total, len(q_pages), a_total, len(a_pages))
        except Exception as e:
            st.error(f"Evaluation failed: {e}")
            st.caption("Check that your API key is valid, the model is available to your account, and the PDF files are readable.")

if "evaluation" in st.session_state:
    st.divider()
    st.subheader("2. Evaluation Report")
    q_total, q_sent, a_total, a_sent = st.session_state.get("page_info", (0,0,0,0))
    st.caption(f"Question paper: {q_sent}/{q_total} pages sent · Answer sheet: {a_sent}/{a_total} pages sent")
    if q_sent < q_total or a_sent < a_total:
        st.warning("Only the selected maximum number of pages was sent. Increase the page limit and run again if later pages contain answers.")
    st.markdown(st.session_state["evaluation"])
    st.download_button(
        "⬇️ Download evaluation as Markdown",
        data=st.session_state["evaluation"],
        file_name="StudyAI_Evaluation_Report.md",
        mime="text/markdown",
        use_container_width=True
    )
    if st.button("Clear report"):
        for key in ["evaluation", "page_info"]:
            st.session_state.pop(key, None)
        st.rerun()

st.divider()
st.markdown('<p class="small-note">Privacy: PDFs are processed in the running app and sent to the configured AI provider for evaluation. Do not upload documents containing sensitive personal information unless you have permission.</p>', unsafe_allow_html=True)
